"""Local static file preview, including the built site's static 404 document.

No application routes, form handling, server actions, or API endpoints.
"""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys

directory = Path(__file__).resolve().parent.parent / "dist"


class StaticPreview(SimpleHTTPRequestHandler):
    def send_error(self, code, message=None, explain=None):
        if code == 404 and (directory / "404.html").exists():
            content = (directory / "404.html").read_bytes()
            self.send_response(404)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(content)
            return
        super().send_error(code, message, explain)


if not directory.exists():
    raise SystemExit("Run npm run build first.")
port = int(sys.argv[1]) if len(sys.argv) > 1 else 4173
server = ThreadingHTTPServer(("127.0.0.1", port), partial(StaticPreview, directory=str(directory)))
print(f"Static preview: http://127.0.0.1:{port}/en/", flush=True)
try:
    server.serve_forever()
except KeyboardInterrupt:
    server.server_close()
