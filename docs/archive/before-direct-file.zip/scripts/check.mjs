import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { groups, services, audiences, industries, steps, faqs, copy } from '../content.js';
assert.equal(groups.length,4); assert.equal(services.length,8); assert.equal(audiences.length,7); assert.equal(industries.length,5);assert.equal(steps.length,4);assert.equal(faqs.length,4);
assert.equal(new Set(services.map(s=>s.id)).size,8);
for(const service of services){assert(groups.some(g=>g.id===service.group));assert(service.uses.length>=2);for(const key of ['title','what','when','outputs'])assert(service[key].every(Boolean));}
for(const item of [...audiences,...industries])assert(services.some(s=>s.id===item.service));
function pairs(value){if(Array.isArray(value)){if(value.length===2&&value.every(x=>typeof x==='string'))assert(value.every(x=>x.trim().length>0));else value.forEach(pairs);}else if(value&&typeof value==='object')Object.values(value).forEach(pairs);}
[groups,services,audiences,industries,steps,faqs,copy].forEach(pairs);
const source=await readFile('app.js','utf8');
assert(!/\b(fetch|XMLHttpRequest|sendBeacon|localStorage|sessionStorage|indexedDB)\b|console\.|document\.cookie/.test(source),'No form transmission, persistence, or logging is permitted.');
assert(!/https?:\/\//.test(source),'No external requests or form destinations.');
const usedKeys=[...source.matchAll(/\bt\('([^']+)'\)/g)].map(m=>m[1]);
for(const key of usedKeys)assert(key in copy,`Missing copy key: ${key}`);
assert(source.includes('ev.preventDefault()'));
for(const lang of ['en','ar'])for(const page of ['','services','process','about','contact','privacy','404']){await access(`dist/${lang}/${page}${page?'/':''}index.html`);const html=await readFile(`dist/${lang}/${page}${page?'/':''}index.html`,'utf8');assert(html.includes(`lang="${lang}"`));assert(html.includes(`dir="${lang==='ar'?'rtl':'ltr'}"`));}
const hash=file=>createHash('sha256').update(file).digest('hex');
assert.equal(hash(await readFile('assets/official-logo.jpg')),hash(await readFile('dist/assets/official-logo.jpg')));
console.log('PASS: content counts, bilingual copy, service references, localized static routes, logo copy, and no transmission/storage/logging APIs.');
const luminance=hex=>{const rgb=hex.match(/\w\w/g).map(x=>parseInt(x,16)/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4);return rgb[0]*.2126+rgb[1]*.7152+rgb[2]*.0722;};
const contrast=(a,b)=>{const x=luminance(a),y=luminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
for(const [foreground,background] of [['242424','ffffff'],['5f5f5f','ffffff'],['5f5f5f','f6f6f6'],['2457d6','ffffff'],['2457d6','edf2fe'],['b5b5b5','111111'],['a9c0ff','111111'],['737373','ffffff']])assert(contrast(foreground,background)>=4.5);
assert(contrast('8c8c8c','ffffff')>=3);
console.log('PASS: primary text/accent/footer color pairs >= 4.5:1; input boundaries >= 3:1.');
