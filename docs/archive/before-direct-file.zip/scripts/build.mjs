import { mkdir, readFile, writeFile, cp, rm } from 'node:fs/promises';
const pages = ['home', 'services', 'process', 'about', 'contact', 'privacy', '404'];
await rm('dist', { recursive: true, force: true });
await mkdir('dist', { recursive: true });
for (const file of ['app.js', 'content.js', 'styles.css']) await cp(file, `dist/${file}`);
await cp('assets', 'dist/assets', { recursive: true });
const shell = await readFile('index.html', 'utf8');
await writeFile('dist/index.html', shell);
await writeFile('dist/404.html', shell);
for (const lang of ['en', 'ar']) {
  for (const page of pages) {
    const path = `dist/${lang}/${page === 'home' ? '' : page}`;
    await mkdir(path, { recursive: true });
    await writeFile(`${path}/index.html`, shell.replace('lang="en" dir="ltr"', `lang="${lang}" dir="${lang === 'ar' ? 'rtl' : 'ltr'}"`));
  }
}
console.log('Static build complete: 14 localized routes, root fallback, and 404.html.');
