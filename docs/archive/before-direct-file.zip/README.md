# MT Software Solutions

Complete bilingual, frontend-only corporate presentation website. English and Arabic have distinct URLs, responsive layouts, shared components, and a truthful local contact-form preview.

## Preview and build

Requirements: Node.js 18+ and Python 3. No package installation is needed; the project has no third-party runtime or build dependencies.

From this project directory:

```sh
npm run build
npm run check
npm run preview
```

Open [English Home](http://127.0.0.1:4173/en/) or [Arabic Home](http://127.0.0.1:4173/ar/). Stop the preview with Ctrl+C. `npm run preview -- 4174` selects an alternative port.

The preview is a local static file server bound only to loopback. It serves files and the static 404 document; it does not implement form submission, application routes, API endpoints, or business logic. JavaScript is required for rendering and local interactions. Opening files directly with `file://` is not supported by the ES modules.

`npm run build` recreates `dist/`, which contains only HTML, CSS, JavaScript, and the official JPG. No deployment or publication has been performed.

## Pages and static hosting

| Page | English | Arabic |
|---|---|---|
| Home | `/en/` | `/ar/` |
| Services | `/en/services/` | `/ar/services/` |
| Our Process | `/en/process/` | `/ar/process/` |
| About Us | `/en/about/` | `/ar/about/` |
| Contact | `/en/contact/` | `/ar/contact/` |
| Privacy | `/en/privacy/` | `/ar/privacy/` |
| Not found | `/en/404/` | `/ar/404/` |

Serve `dist/` at the hosting origin's root; assets use root-relative paths. The root URL falls back to English. Keep directory `index.html` handling enabled and configure `404.html` as the hosting provider's custom error document, retaining the originally requested URL. This lets the app identify the unknown route and its locale. The local preview already implements that static error-document behavior. No universal SPA rewrite is needed for the generated known routes.

Service group anchors: `#business`, `#mobile`, `#connected`, `#operations`. Individual service anchors: `#custom`, `#web`, `#mobile-app`, `#backend-api`, `#integration`, `#consulting`, `#support`, `#cloud`.

Contact preselection uses only a stable service identifier, for example `/ar/contact/?service=integration`. Personal information is never added to URLs.

## Project organization

- `content.js`: all localized copy, confirmed services, audience categories, industry examples, steps and FAQ.
- `app.js`: reusable rendering helpers, routing, navigation, local validation and inquiry preview.
- `styles.css`: visual foundation, responsive layouts, RTL, focus, reduced motion and component states.
- `assets/official-logo.jpg`: byte-identical copy of the supplied official logo.
- `scripts/build.mjs`: static page generation; `scripts/check.mjs`: relevant content and integrity checks.
- `scripts/preview.py`: development-only static file server with a custom static 404 document.
- `docs/`: design reference, completed checklist, verification and content decisions.
- `screenshots/`: actual rendered-site captures and browser check reports.

## Contact behavior

The form validates required name, email, and details fields locally. Errors preserve input and focus the first invalid field. A valid form shows **“Preview only — your inquiry has not been sent.”** with a temporary summary, edit and reset controls.

Entered values are held only in temporary page memory. There is no submission request, email, upload, browser storage, logging of field contents, analytics, database or third-party form service. Leaving Contact, resetting, or reloading clears the application's state; changing language on Contact preserves it in memory and keeps the selected service stable. Browser-managed autofill is independent of this application.

## Verification and decisions

See `docs/VERIFICATION.md` for actual checks and capture details, and `docs/CONTENT-DECISIONS.md` for remaining business content decisions. This implementation targets accessible practices; it does not claim certified WCAG conformance.
