# Verification — 11 October 2026

## Passed checks

- `npm run build`: generates 14 localized static routes, root fallback and `404.html`.
- `npm run check`: JavaScript syntax, all 8 services / 4 groups / 7 audiences / 5 industries, bilingual content, service references, localized route files, copied logo integrity, and absence of transmission, persistence and field-logging APIs.
- Original source logo and project asset have identical SHA-256 hashes; the built copy is also identical.
- Main body, secondary text, accent, footer and small card-number color pairs meet 4.5:1 in the checked palette; form boundaries meet 3:1.
- 56 browser page/layout observations: all 7 page types in both languages at 1440, 768, 390 and 320px. One H1 per page, correct language/direction, no horizontal overflow, and no missing logo images.
- 406 rendered internal route and anchor references resolve to implemented destinations.
- 41 browser interaction assertions passed: accessible menu opening/dismissal/focus return; route and section preservation on language switching; all 8 service actions; local required-field/email errors; first-invalid focus; preserved values; translated errors and preview; edit/reset; clearing on leaving Contact; FAQ keyboard operation; skip-link focus; and localized unknown-route recovery.
- Main page and interaction run produced no unexpected console warnings or errors. The intentionally unknown route returns HTTP 404 and displays the site's localized error page.
- HTTP readiness returned 200; the static preview's unknown-route response returned 404 with the custom error document.
- Additional Chrome checks confirmed Arabic Home, Services, Process, About, Contact, Privacy and Not-found layouts at 1440 and 390px without horizontal overflow.

## Visual evidence

Actual screenshots are in `screenshots/`. English full-page captures cover every page at desktop and mobile widths. Arabic desktop/mobile captures are viewport images for every page, with additional tablet/narrow examples. Representative final views are `en-home-desktop-preview.jpg` and `ar-home-mobile-preview.jpg`.

The in-app browser's exported Arabic images were horizontally clipped despite correct live rendering and DOM geometry. Chrome viewport captures replaced those artifacts. Chrome's full-page stitching repeated the initial viewport, so only its reliable viewport captures are included for Arabic. These capture limitations are not represented as site layout failures.

Contact preview/edit images contain synthetic testing values only (`Preview Test`, `demo@example.invalid`), not verified company contact information. These values are absent from shipped site content. Email preservation was confirmed visually because browser inspection redacted email field values.

`browser-layout-report.json`, `browser-interaction-report.json`, and `chrome-arabic-report.json` record the actual observations. Geometry checks and representative visual review are not a full assistive-technology or certified accessibility audit. No screen-reader session or real-user usability study was performed.

## Delivery scope

The delivered site has no application backend, database, authentication, API endpoint, server action, payment flow, external form submission, email/CRM service, analytics or AI functionality. All dependencies and assets needed at runtime are local. Node only generates static files; the Python helper only previews static files. No deployment, external integration or pull request was created.
