import {pick, groups, services, audiences, industries, steps, faqs, copy} from './content.js';
const pages = ['home','services','process','about','contact','privacy','404'];
const app = document.querySelector('#app');
let locale = 'en', page = 'home', menuOpen = false, previewMode = false, errors = {}, resetMessage = false;
const emptyForm = () => ({name:'',email:'',organization:'',service:'choose',phone:'',details:''});
let form = emptyForm();
const e = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const anchorId = hash => { try { return decodeURIComponent(hash.slice(1)); } catch { return hash.slice(1); } };
const p = pair => pick(pair, locale);
const t = key => p(copy[key]);
const paths = {window:'M3 5h18v14H3z M3 9h18 M7 7h.01 M10 7h.01 M7 13h4 M7 16h8',mobile:'M7 2h10v20H7z M10 18h4',connect:'M3 3h6v6H3z M15 15h6v6h-6z M6 9v9h9 M15 3h6v6h-6z M9 6h6',settings:'M4 7h16 M4 17h16 M8 4v6 M16 14v6',arrow:'M5 12h14 M13 6l6 6-6 6',bag:'M4 7h16l1 14H3z M8 7V5a4 4 0 0 1 8 0v2',book:'M12 5v16 M12 5C9 2 5 3 2 4v15c4-1 7-1 10 2 M12 5c3-3 7-2 10-1v15c-4-1-7-1-10 2',plus:'M8 3h8v5h5v8h-5v5H8v-5H3V8h5z',building:'M5 21V3h14v18 M2 21h20 M9 7h1 M14 7h1 M9 11h1 M14 11h1 M10 21v-6h4v6',truck:'M2 5h12v12H2z M14 9h4l4 4v4h-8 M7 19a2 2 0 1 0-4 0 2 2 0 0 0 4 0 M21 19a2 2 0 1 0-4 0 2 2 0 0 0 4 0',check:'M5 12l4 4L19 6',globe:'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0 M3 12h18 M12 3c5 5 5 13 0 18-5-5-5-13 0-18',chevron:'M6 9l6 6 6-6'};
const icon = (name, cls='') => `<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name] || paths.window}"/></svg>`;
const url = (target='home', suffix='', lang=locale) => `/${lang}/${target === 'home' ? '' : `${target}/`}${suffix}`;
const link = (target, label, cls='', suffix='') => `<a class="${cls}" ${cls==='active'?'aria-current="page"':''} href="${url(target,suffix)}">${e(label)}</a>`;
const action = (target='contact', label=t('discuss'), secondary=false, suffix='') => `<a class="button ${secondary?'secondary':'primary'}" href="${url(target,suffix)}">${e(label)}${icon('arrow','directional')}</a>`;
const textLink = (target,label,suffix='') => `<a class="text-link" href="${url(target,suffix)}">${e(label)}${icon('arrow','directional')}</a>`;
const logo = () => `<span class="logo-frame"><img src="/assets/official-logo.jpg" alt="MT Software Solutions" width="1000" height="1000"></span>`;
function readRoute() {
  const parts = location.pathname.split('/').filter(Boolean);
  if (parts.length === 0) { locale='en';page='home';return; }
  locale = parts[0] === 'ar' ? 'ar' : 'en';
  const validLang = parts[0] === 'en' || parts[0] === 'ar';
  const target = parts[1] || 'home';
  page = validLang && parts.length <= 2 && pages.includes(target) ? target : '404';
}
function header() {
  const nextLocale = locale === 'en' ? 'ar' : 'en';
  const suffix = (page==='contact' && services.some(s=>s.id===form.service) ? `?service=${form.service}` : '') + location.hash;
  return `<a href="#main" class="skip-link">${e(t('skip'))}</a><header class="site-header"><div class="container header-inner">
    <a href="${url()}" class="logo-link" aria-label="${e(`${t('backHome')} — MT Software Solutions`)}">${logo()}</a>
    <nav class="desktop-nav" aria-label="${e(t('footerLinks'))}">${copy.nav.map((name,i)=>link(pages[i],p(name),page===pages[i]?'active':'')).join('')}</nav>
    <div class="header-actions"><a class="language-switch" href="${url(page,suffix,nextLocale)}" lang="${nextLocale}" hreflang="${nextLocale}">${icon('globe')}<span>${nextLocale==='ar'?'العربية':'English'}</span></a>${action('contact',t('discuss'),false)}<button type="button" class="menu-trigger" aria-controls="mobile-nav" aria-expanded="${menuOpen}" aria-label="${e(t(menuOpen?'close':'menu'))}"><span></span><span></span></button></div>
  </div><nav id="mobile-nav" class="mobile-nav container" aria-label="${e(t('menu'))}" ${menuOpen?'':'hidden'}>${copy.nav.map((name,i)=>link(pages[i],p(name),page===pages[i]?'active':'')).join('')}${action()}</nav></header>`;
}
function footer() {
 return `<footer class="site-footer"><div class="container footer-top"><div class="footer-brand"><a href="${url()}">${logo()}</a><p>${e(t('footerDescription'))}</p></div><div class="footer-nav"><h2>${e(t('footerLinks'))}</h2><nav aria-label="${e(t('footerLinks'))}">${copy.nav.map((name,i)=>link(pages[i],p(name))).join('')}${link('privacy',t('privacy'))}</nav></div><div class="footer-invitation"><h2>${e(t('finalTitle'))}</h2>${textLink('contact',t('discuss'))}<p>${e(t('footerNote'))}</p></div></div><div class="container footer-bottom"><small>© ${e(t('rights'))}</small><small>${e(t('footerNote'))}</small></div></footer>`;
}
const heading = (kicker,title,description='',level='h2') => `<div class="section-heading">${kicker?`<p class="eyebrow">${e(kicker)}</p>`:''}<${level}>${e(title)}</${level}>${description?`<p class="lede">${e(description)}</p>`:''}</div>`;
const invitation = () => `<section class="invitation"><div class="container invitation-inner"><div><h2>${e(t('finalTitle'))}</h2><p>${e(t('finalDescription'))}</p></div>${action()}</div></section>`;
function concept() {
 return `<figure class="concept"><div class="concept-canvas"><div class="concept-grid"></div><div class="connection connection-one"></div><div class="connection connection-two"></div><div class="connection connection-three"></div>
 <div class="concept-window"><div class="window-chrome"><span></span><span></span><span></span><i></i></div><div class="mock-ui"><div class="mock-sidebar"><i></i><i></i><i></i></div><div class="mock-body"><div class="mock-line"></div><div class="mock-columns"><span></span><span></span></div><div class="mock-lines"><i></i><i></i><i></i></div></div></div><div class="concept-label">${icon('window')}${e(t('webLabel'))}</div></div>
 <div class="concept-hub">${icon('connect')}<strong>${e(t('goalLabel'))}</strong><small>${e(t('connectedLabel'))}</small></div>
 <div class="concept-phone"><div class="phone-speaker"></div><div class="phone-panel">${icon('mobile')}<i></i><i></i><span></span><span></span></div><div class="concept-label">${e(t('mobileLabel'))}</div></div>
 <div class="concept-system">${icon('settings')}<div><strong>${e(t('systemLabel'))}</strong><span class="system-bars"><i></i><i></i><i></i></span></div></div></div><figcaption>${e(t('concept'))}</figcaption></figure>`;
}
function serviceCards() {
 return `<div class="service-grid">${groups.map((g,i)=>`<a class="service-card" href="${url('services',`#${g.id}`)}"><div class="card-top"><span class="icon-box">${icon(g.icon)}</span><span class="card-number">0${i+1}</span></div><h3>${e(p(g.title))}</h3><p>${e(p(g.description))}</p><span class="card-link">${e(t('explore'))}${icon('arrow','directional')}</span></a>`).join('')}</div>`;
}
function audienceGrid() {
 return `<div class="audience-grid">${audiences.map(a=>`<article class="audience-item"><h3>${e(p(a.title))}</h3><p>${e(p(a.need))}</p>${textLink('services',p(services.find(s=>s.id===a.service).title),`#${a.service}`)}</article>`).join('')}</div>`;
}
function industryGrid() {
 return `<div class="industry-grid">${industries.map(a=>`<article class="industry-item">${icon(a.icon)}<h3>${e(p(a.title))}</h3><p>${e(p(a.need))}</p>${textLink('services',t('related'),`#${a.service}`)}</article>`).join('')}</div>`;
}
function home() {
 return `<section class="hero"><div class="container hero-inner"><div class="hero-copy"><p class="eyebrow">${e(t('heroKicker'))}</p><h1>${e(t('heroTitle'))}</h1><p class="hero-description">${e(t('heroDescription'))}</p><div class="actions">${action()}${action('services',t('explore'),true)}</div></div>${concept()}</div></section>
 <section class="help-section"><div class="container"><div class="help-heading">${heading(t('helpKicker'),t('helpTitle'))}</div><div class="help-grid">${copy.help.map((h,i)=>`<div class="help-item"><span class="small-index">0${i+1}</span><h3>${e(p(h))}</h3></div>`).join('')}</div></div></section>
 <section class="section"><div class="container"><div class="heading-row">${heading(t('servicesKicker'),t('servicesTitle'),t('servicesDescription'))}${textLink('services',t('allServices'))}</div>${serviceCards()}</div></section>
 <section class="section alternate"><div class="container">${heading(t('audienceKicker'),t('audienceTitle'),t('audienceDescription'))}${audienceGrid()}<div class="industry-heading"><h2>${e(t('industryTitle'))}</h2><p>${e(t('industryDescription'))}</p></div>${industryGrid()}<div class="other-industry">${textLink('contact',t('otherIndustry'))}</div></div></section>
 <section class="section"><div class="container">${heading(t('processKicker'),t('processTitle'),t('processDescription'))}<div class="process-grid">${steps.map((s,i)=>`<article class="process-item"><span class="step-number">0${i+1}</span><h3>${e(p(s.title))}</h3><p>${e(p(s.description))}</p></article>`).join('')}</div>${textLink('process',t('processLink'))}</div></section>
 <section class="section alternate"><div class="container company-section"><div>${heading(t('aboutKicker'),t('aboutTitle'),t('aboutDescription'))}${textLink('about',t('aboutLink'))}</div><aside class="trust-panel">${icon('connect')}<h3>${e(t('trustTitle'))}</h3><p>${e(t('trustDescription'))}</p></aside></div></section>
 <section class="section"><div class="container faq-layout">${heading(t('faqKicker'),t('faqTitle'))}<div class="faq-list">${faqs.map(f=>`<details><summary>${e(p(f.q))}${icon('chevron')}</summary><p>${e(p(f.a))}</p></details>`).join('')}</div></div></section>${invitation()}`;
}
function servicePage() {
 return `<section class="page-intro"><div class="container">${heading(t('servicesKicker'),t('servicePageTitle'),t('servicePageDescription'),'h1')}<p class="note-text">${e(t('serviceDistinction'))}</p><nav class="group-nav" aria-label="${e(t('allServices'))}">${groups.map(g=>link('services',p(g.title),'group-pill',`#${g.id}`)).join('')}</nav></div></section>
 ${groups.map((g,gi)=>`<section class="section service-group ${gi%2?'alternate':''}" id="${g.id}"><div class="container"><div class="group-heading"><span class="icon-box">${icon(g.icon)}</span><div><p class="eyebrow">0${gi+1}</p><h2>${e(p(g.title))}</h2></div></div><div class="service-details">${services.filter(s=>s.group===g.id).map(s=>`<article class="service-detail" id="${s.id}"><div class="service-definition"><h3>${e(p(s.title))}</h3><p>${e(p(s.what))}</p>${action('contact',t('serviceContact'),true,`?service=${s.id}`)}</div><div class="service-context"><h4>${e(t('when'))}</h4><p>${e(p(s.when))}</p><h4>${e(t('examples'))}</h4><ul>${s.uses.map(u=>`<li>${e(p(u))}</li>`).join('')}</ul><h4>${e(t('outputs'))}</h4><p>${e(p(s.outputs))}</p></div></article>`).join('')}</div></div></section>`).join('')}${invitation()}`;
}
function processPage() {
 return `<section class="page-intro"><div class="container">${heading(t('processKicker'),t('processPageTitle'),t('processDescription'),'h1')}</div></section><section class="section"><div class="container process-sequence">${steps.map((s,i)=>`<article class="expanded-step"><div class="step-number">0${i+1}</div><div><h2>${e(p(s.title))}</h2><p class="step-lede">${e(p(s.description))}</p><p>${e(p(s.detail))}</p></div></article>`).join('')}</div></section>
 <section class="section alternate"><div class="container prepare-layout">${heading('',t('prepareTitle'),t('prepareDescription'))}<ul class="prepare-list">${copy.prepare.map(x=>`<li>${icon('check')}<span>${e(p(x))}</span></li>`).join('')}</ul></div></section><section class="section"><div class="container narrow">${heading('',t('collaborationTitle'),t('collaborationText'))}</div></section>${invitation()}`;
}
function aboutPage() {
 return `<section class="page-intro"><div class="container">${heading(t('aboutKicker'),t('aboutPageTitle'),t('aboutDescription'),'h1')}</div></section><section class="section"><div class="container"><h2>${e(t('approachTitle'))}</h2><div class="approach-grid">${[0,2,4].map((i,index)=>`<article><span class="small-index">0${index+1}</span><h3>${e(p(copy.approachItems[i]))}</h3><p>${e(p(copy.approachItems[i+1]))}</p></article>`).join('')}</div><p class="approach-note">${e(t('trustDescription'))}</p></div></section><section class="section alternate"><div class="container">${heading(t('audienceKicker'),t('audienceTitle'),t('audienceDescription'))}${audienceGrid()}</div></section>${invitation()}`;
}
function field(id,required=false,type='text') {
 const error = errors[id] ? t(`${id}Error`) : '';
 const label = `<label for="${id}">${e(t(id))}${required?'<span aria-hidden="true"> *</span>':` <span class="optional">(${e(t('optional'))})</span>`}</label>`;
 const helper = id==='details' ? `<p class="field-helper" id="details-helper">${e(t('detailsHelper'))}</p>` : '';
 const described = [id==='details'?'details-helper':'',error?`${id}-error`:''].filter(Boolean).join(' ');
 const attrs = `id="${id}" name="${id}" ${required?'required':''} ${error?'aria-invalid="true"':''} ${described?`aria-describedby="${described}"`:''}`;
 let input;
 if(id==='service') input=`<select ${attrs}><option value="choose">${e(t('choose'))}</option>${services.map(s=>`<option value="${s.id}" ${form.service===s.id?'selected':''}>${e(p(s.title))}</option>`).join('')}</select>`;
 else if(id==='details') input=`<textarea ${attrs} rows="5">${e(form[id])}</textarea>`;
 else input=`<input ${attrs} type="${type}" value="${e(form[id])}" autocomplete="${{name:'name',email:'email',phone:'tel',organization:'organization'}[id]}" ${['email','phone'].includes(id)?'dir="ltr"':''}>`;
 return `<div class="form-field ${id==='details'?'full-width':''}">${label}${input}${helper}${error?`<p class="field-error" id="${id}-error">${e(error)}</p>`:''}</div>`;
}
function formContent() {
 if(previewMode) return `<div class="preview-summary"><span class="icon-box">${icon('check')}</span><h2 tabindex="-1" id="preview-heading">${e(t('previewTitle'))}</h2><p>${e(t('previewDescription'))}</p><dl>${['name','email','organization','service','phone','details'].map(id=>`<div><dt>${e(t(id))}</dt><dd ${['email','phone'].includes(id)?'dir="ltr"':''}>${e(id==='service'?form.service==='choose'?t('choose'):p(services.find(s=>s.id===form.service).title):form[id]||t('notProvided'))}</dd></div>`).join('')}</dl><div class="actions"><button type="button" class="button primary" id="edit-form">${e(t('edit'))}</button><button type="button" class="button secondary" id="reset-form">${e(t('reset'))}</button></div></div>`;
 return `<form id="inquiry-form" novalidate><p class="required-note">${e(t('requiredNote'))}</p>${Object.keys(errors).length?`<p class="error-summary" role="alert">${e(t('errorSummary'))}</p>`:''}<div class="form-grid">${field('name',true)}${field('email',true,'email')}${field('organization')}${field('phone',false,'tel')}${field('service')}${field('details',true)}</div><div class="form-actions"><button type="submit" class="button primary">${e(t('preview'))}${icon('arrow','directional')}</button><button type="button" class="reset-link" id="reset-form">${e(t('reset'))}</button></div><p class="form-status" role="status">${resetMessage?e(t('resetStatus')):''}</p></form>`;
}
function contactPage() {
 return `<section class="section contact-section"><div class="container contact-layout"><div class="contact-copy">${heading(t('contactKicker'),t('contactTitle'),t('contactDescription'),'h1')}<h2>${e(t('contactPrepare'))}</h2><ul class="prepare-list">${copy.contactPoints.map(x=>`<li>${icon('check')}<span>${e(p(x))}</span></li>`).join('')}</ul></div><div class="contact-card"><aside class="preview-notice"><strong>${e(t('noticeTitle'))} / ${locale==='en'?'معاينة محلية فقط':'Local preview only'}</strong><p>${e(t('notice'))}</p><p lang="${locale==='en'?'ar':'en'}" dir="${locale==='en'?'rtl':'ltr'}" class="notice-translation">${e(pick(copy.notice,locale==='en'?'ar':'en'))}</p>${link('privacy',t('privacy'))}</aside><div id="form-area">${formContent()}</div></div></div></section>`;
}
function privacyPage() {
 return `<section class="page-intro"><div class="container">${heading(t('privacy'),t('privacyTitle'),t('privacyIntro'),'h1')}</div></section><section class="section"><div class="container prose">${copy.privacySections.map(s=>`<section><h2>${e(p(s.title))}</h2><p>${e(p(s.text))}</p></section>`).join('')}${action('contact',p(copy.nav[4]),true)}</div></section>`;
}
function notFound() {
 return `<section class="section not-found"><div class="container"><span class="error-code" aria-hidden="true">404</span>${heading(t('notFoundKicker'),t('notFoundTitle'),t('notFoundDescription'),'h1')}<div class="actions">${action('home',t('backHome'))}${action('services',t('explore'),true)}</div></div></section>`;
}
function render({focus=false}={}) {
 document.documentElement.lang=locale;
 document.documentElement.dir=locale==='ar'?'rtl':'ltr';
 const title=page==='home'?'MT Software Solutions':`${page==='privacy'?t('privacy'):page==='404'?t('notFoundKicker'):p(copy.nav[pages.indexOf(page)])} | MT Software Solutions`;
 document.title=title;
 document.querySelector('meta[name="description"]').content=t('footerDescription');
 const content={home,services:servicePage,process:processPage,about:aboutPage,contact:contactPage,privacy:privacyPage,'404':notFound}[page]();
 app.innerHTML=header()+`<main id="main" tabindex="-1">${content}</main>`+footer();
 bind();
 if(focus) document.querySelector('#main').focus({preventScroll:true});
}
function updateForm() {
 document.querySelector('#form-area').innerHTML=formContent();
 bindForm();
}
function syncLanguageLink() {
 const suffix=(services.some(s=>s.id===form.service)?`?service=${form.service}`:'')+location.hash;
 document.querySelector('.language-switch')?.setAttribute('href',url(page,suffix,locale==='en'?'ar':'en'));
}
function bindForm() {
 const currentForm=document.querySelector('#inquiry-form');
 currentForm?.addEventListener('input',ev=>{if(ev.target.name in form) {form[ev.target.name]=ev.target.value;resetMessage=false;if(ev.target.name==='service')syncLanguageLink();}});
 currentForm?.addEventListener('change',ev=>{if(ev.target.name in form) {form[ev.target.name]=ev.target.value;if(ev.target.name==='service')syncLanguageLink();}});
 currentForm?.addEventListener('submit',ev=>{
  ev.preventDefault();
  const values=new FormData(currentForm);
  for(const key of Object.keys(form)) form[key]=String(values.get(key)||'');
  errors={};
  if(!form.name.trim()) errors.name=true;
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) errors.email=true;
  if(!form.details.trim()) errors.details=true;
  if(Object.keys(errors).length) {updateForm();document.getElementById(Object.keys(errors)[0]).focus();return;}
  previewMode=true;updateForm();document.querySelector('#preview-heading').focus();
 });
 document.querySelector('#reset-form')?.addEventListener('click',()=>{form=emptyForm();previewMode=false;errors={};resetMessage=true;history.replaceState(null,'',url('contact'));syncLanguageLink();updateForm();document.querySelector('#name').focus();});
 document.querySelector('#edit-form')?.addEventListener('click',()=>{previewMode=false;updateForm();document.querySelector('#name').focus();});
}
function setMenu(open,{returnFocus=false}={}) {
 menuOpen=open;
 const nav=document.querySelector('#mobile-nav'),trigger=document.querySelector('.menu-trigger');
 nav.hidden=!open;trigger.setAttribute('aria-expanded',String(open));trigger.setAttribute('aria-label',t(open?'close':'menu'));
 if(returnFocus) trigger.focus();
}
function bind() {
 document.querySelector('.menu-trigger').addEventListener('click',()=>setMenu(!menuOpen));
 bindForm();
}
function navigate(href, focus=true) {
 const previousPage=page;
 history.pushState(null,'',href);
 readRoute();menuOpen=false;
 if(previousPage==='contact'&&page!=='contact') {form=emptyForm();previewMode=false;errors={};}
 if(page==='contact') {
  const selection=new URLSearchParams(location.search).get('service');
  if(services.some(s=>s.id===selection)&&selection!==form.service) {form.service=selection;previewMode=false;}
 }
 render({focus});
 if(location.hash) document.getElementById(anchorId(location.hash))?.scrollIntoView();
 else window.scrollTo(0,0);
}
app.addEventListener('click',ev=>{
 const a=ev.target.closest('a');
 if(!a||ev.ctrlKey||ev.metaKey||ev.shiftKey||ev.altKey||ev.button!==0)return;
 if(a.getAttribute('href')==='#main') {ev.preventDefault();document.querySelector('#main').focus();document.querySelector('#main').scrollIntoView();return;}
 const dest=new URL(a.href,location.href);
 if(dest.origin!==location.origin)return;
 ev.preventDefault();
 if(dest.pathname===location.pathname && dest.search===location.search && dest.hash && !a.classList.contains('language-switch')) {
  history.pushState(null,'',dest.href);menuOpen&&setMenu(false);
  const target=document.getElementById(anchorId(dest.hash));
  if(target) {target.setAttribute('tabindex','-1');target.focus({preventScroll:true});target.scrollIntoView();}
 } else navigate(dest.href);
});
document.addEventListener('keydown',ev=>{if(ev.key==='Escape'&&menuOpen)setMenu(false,{returnFocus:true});});
document.addEventListener('click',ev=>{if(menuOpen&&!ev.target.closest('.site-header'))setMenu(false);});
window.addEventListener('popstate',()=>{
 const previousPage=page;readRoute();menuOpen=false;
 if(previousPage==='contact'&&page!=='contact') {form=emptyForm();previewMode=false;errors={};}
 if(page==='contact') {const s=new URLSearchParams(location.search).get('service');if(services.some(x=>x.id===s))form.service=s;}
 render({focus:true});
 if(location.hash)document.getElementById(anchorId(location.hash))?.scrollIntoView();
});
window.matchMedia('(min-width: 1001px)').addEventListener('change',ev=>{if(ev.matches&&menuOpen)setMenu(false);});
readRoute();
if(page==='contact') {const s=new URLSearchParams(location.search).get('service');if(services.some(x=>x.id===s))form.service=s;}
render();
if(location.hash)requestAnimationFrame(()=>document.getElementById(anchorId(location.hash))?.scrollIntoView());
